package originalSystem.GPC.CicloVendite;


public class DDTUscita {
	
	private int id;
	private String Data;
	private int idFattUscita;
	
	public String getData() {
		return Data;
	}
	public void setData(String data) {
		Data = data;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getIdFattUscita() {
		return idFattUscita;
	}
	public void setIdFattUscita(int idFattUscita) {
		this.idFattUscita = idFattUscita;
	}
	
	

}
