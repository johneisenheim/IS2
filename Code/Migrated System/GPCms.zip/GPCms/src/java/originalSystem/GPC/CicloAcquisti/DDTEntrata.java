package originalSystem.GPC.CicloAcquisti;


public class DDTEntrata {
	
	private int id;
	private String Data;
	private int idFattEntrata;
	
	public String getData() {
		return Data;
	}
	public void setData(String data) {
		Data = data;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getIdFattEntrata() {
		return idFattEntrata;
	}
	public void setIdFattEntrata(int idFattEntrata) {
		this.idFattEntrata = idFattEntrata;
	}

	

}
