/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package migratedSystem.SellsCycle;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import migratedSystem.json.JSONObject;
import originalSystem.GPC.CicloVendite.Cliente;
import originalSystem.GPC.CicloVendite.GestioneCliente;

/**
 *
 * @author johneisenheim
 */
public class addClient extends HttpServlet {
    
    private final JSONObject message = new JSONObject();
    private Cliente client = null;
    private final GestioneCliente handleclient = new GestioneCliente();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        client = new Cliente(0,request.getParameter("name"), request.getParameter("surname"), request.getParameter("codfis"), request.getParameter("address"), request.getParameter("category"), request.getParameter("loc"), request.getParameter("prov"), Integer.parseInt(request.getParameter("cap")), Double.parseDouble(request.getParameter("fid")), request.getParameter("ragsoc"), request.getParameter("telephone"), request.getParameter("mobile"), request.getParameter("payment"));
        //Cliente client = new Cliente(732,"Sandokan", "Crist", "SLNNLL", "Via Montano", "Cane", "Lecco", "CU", 98872, 7.0, "Impatto", "0771/326322", "320/392934982", "Contanti");;
        try{
            handleclient.inserisciCliente(client);
            message.put("status", 1);
            message.put("message", "Client added successfully!");
            response.getWriter().write(message.toString());
        }catch(SQLException e){
            message.put("status", 0);
            message.put("message", "SQL Exception");
            response.getWriter().write(message.toString());
        }catch( ClassNotFoundException e ){
            message.put("status", 0);
            message.put("message", "Class Not Found Exception");
            response.getWriter().write(message.toString());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
